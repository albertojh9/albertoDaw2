<?php
/**
 * MODELO VICTIMA
 * Gestiona operaciones de víctimas
 */
class Victima {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    /**
     * Registra una nueva víctima
     */
    public function crear($datos) {
        $sql = "INSERT INTO Victima (nombre, apellidos, tipo_documento, documento, telefono, observaciones) 
                VALUES (:nombre, :apellidos, :tipo_documento, :documento, :telefono, :observaciones)";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':nombre' => $datos['nombre'] ?: null,
            ':apellidos' => $datos['apellidos'] ?: null,
            ':tipo_documento' => $datos['tipo_documento'] ?: null,
            ':documento' => $datos['documento'] ?: null,
            ':telefono' => $datos['telefono'] ?: null,
            ':observaciones' => $datos['observaciones'] ?: null
        ]);
    }
    
    /**
     * Obtiene todas las víctimas
     */
    public function obtenerTodas() {
        $sql = "SELECT * FROM Victima ORDER BY id DESC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll();
    }
    
    /**
     * Valida un NIF español
     */
    public function validarNIF($nif) {
        $nif = strtoupper(trim($nif));
        if (!preg_match('/^[0-9]{8}[A-Z]$/', $nif)) return false;
        
        $letras = 'TRWAGMYFPDXBNJZSQVHLCKE';
        $numero = substr($nif, 0, 8);
        $letra = substr($nif, 8, 1);
        return $letra === $letras[$numero % 23];
    }
    
    /**
     * Valida un NIE español
     */
    public function validarNIE($nie) {
        $nie = strtoupper(trim($nie));
        if (!preg_match('/^[XYZ][0-9]{7}[A-Z]$/', $nie)) return false;
        
        $letras = 'TRWAGMYFPDXBNJZSQVHLCKE';
        $nieNumero = str_replace(['X', 'Y', 'Z'], ['0', '1', '2'], $nie);
        $numero = substr($nieNumero, 0, 8);
        $letra = substr($nie, 8, 1);
        return $letra === $letras[$numero % 23];
    }
}
