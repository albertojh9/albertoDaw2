<?php
/**
 * Punto de entrada único de la aplicación VioGen
 * Implementa el patrón Front Controller con middleware de autenticación
 */

// Iniciar sesión
session_start();

// Cargar configuración
require_once __DIR__ . '/config/config.php';

// Cargar controladores
require_once CONTROLLER_PATH . 'AuthController.php';
require_once CONTROLLER_PATH . 'VictimaController.php';
require_once CONTROLLER_PATH . 'AgresionController.php';
require_once CONTROLLER_PATH . 'MenuController.php';

// Obtener acción solicitada
$action = $_GET['action'] ?? 'login';

// Acciones que no requieren autenticación
$accionesPublicas = ['login', 'procesar_login'];

// Middleware de autenticación
if (!in_array($action, $accionesPublicas)) {
    if (!isset($_SESSION['usuario_id'])) {
        // Usuario no autenticado - Error 401
        http_response_code(401);
        include VIEW_PATH . '401.php';
        exit;
    }
}

// Si el usuario está autenticado e intenta acceder al login, redirigir al menú
if (in_array($action, ['login', 'procesar_login']) && isset($_SESSION['usuario_id'])) {
    header('Location: index.php?action=menu');
    exit;
}

// Enrutador
switch ($action) {
    // Autenticación
    case 'login':
        $controller = new AuthController();
        $controller->mostrarLogin();
        break;
        
    case 'procesar_login':
        $controller = new AuthController();
        $controller->login();
        break;
        
    case 'logout':
        $controller = new AuthController();
        $controller->logout();
        break;
    
    // Menú principal
    case 'menu':
        $controller = new MenuController();
        $controller->mostrar();
        break;
    
    // Víctimas
    case 'registrar_victima':
        $controller = new VictimaController();
        $controller->mostrarFormulario();
        break;
        
    case 'procesar_victima':
        $controller = new VictimaController();
        $controller->registrar();
        break;
    
    // Agresiones
    case 'registrar_agresion':
        $controller = new AgresionController();
        $controller->mostrarFormulario();
        break;
        
    case 'procesar_agresion':
        $controller = new AgresionController();
        $controller->registrar();
        break;
    
    // Acción por defecto
    default:
        if (isset($_SESSION['usuario_id'])) {
            header('Location: index.php?action=menu');
        } else {
            header('Location: index.php?action=login');
        }
        exit;
}
