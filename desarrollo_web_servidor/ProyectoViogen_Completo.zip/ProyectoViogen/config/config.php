<?php
/**
 * Archivo de configuración del sistema VioGen
 * Contiene todas las constantes de configuración
 */

// Configuración de la base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'viogen');
define('DB_USER', 'uviogen');
define('DB_PASS', 'cviogen');
define('DB_CHARSET', 'utf8mb4');

// Configuración de la aplicación
define('APP_NAME', 'Sistema VioGen');
define('APP_VERSION', '1.0.0');

// Configuración de rutas (relativas)
define('BASE_PATH', dirname(__DIR__) . '/');
define('CONTROLLER_PATH', BASE_PATH . 'controlador/');
define('MODEL_PATH', BASE_PATH . 'modelo/');
define('VIEW_PATH', BASE_PATH . 'vista/');

// Configuración de sesión
define('SESSION_NAME', 'viogen_session');
define('SESSION_LIFETIME', 3600); // 1 hora

// Tipos de documento válidos
define('TIPOS_DOCUMENTO', ['NIF', 'NIE', 'Pasaporte']);

// Tipos de agresión válidos
define('TIPOS_AGRESION', ['física', 'psicológica', 'sexual', 'vicaria']);

// Mensajes del sistema
define('MSG_LOGIN_ERROR', 'Usuario o contraseña incorrectos');
define('MSG_LOGIN_SUCCESS', 'Sesión iniciada correctamente');
define('MSG_LOGOUT_SUCCESS', 'Sesión cerrada correctamente');
define('MSG_VICTIMA_REGISTRADA', 'Víctima registrada correctamente');
define('MSG_AGRESION_REGISTRADA', 'Agresión registrada correctamente');
define('MSG_ERROR_CAMPOS', 'Por favor, complete los campos obligatorios');
define('MSG_ERROR_VALIDACION', 'Error en la validación de datos');
define('MSG_UNAUTHORIZED', 'Acceso no autorizado');

// Configuración de validación
define('MIN_LENGTH_USER', 4);
define('MIN_LENGTH_PASS', 4);
