<?php
/**
 * Clase Victima - Modelo para gestión de víctimas
 */

require_once MODEL_PATH . 'Database.php';

class Victima {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Registrar nueva víctima
     * @param array $datos Datos de la víctima
     * @return int|false ID de la víctima o false si falla
     */
    public function registrar($datos) {
        $sql = "INSERT INTO Victima (nombre, apellidos, tipo_documento, documento, telefono, observaciones) 
                VALUES (:nombre, :apellidos, :tipo_documento, :documento, :telefono, :observaciones)";
        
        $stmt = $this->db->prepare($sql);
        
        try {
            $stmt->execute([
                ':nombre' => $datos['nombre'] ?: null,
                ':apellidos' => $datos['apellidos'] ?: null,
                ':tipo_documento' => $datos['tipo_documento'] ?: null,
                ':documento' => $datos['documento'] ?: null,
                ':telefono' => $datos['telefono'] ?: null,
                ':observaciones' => $datos['observaciones'] ?: null
            ]);
            return $this->db->lastInsertId();
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Obtener todas las víctimas
     * @return array
     */
    public function obtenerTodas() {
        $sql = "SELECT * FROM Victima ORDER BY id DESC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll();
    }

    /**
     * Obtener víctima por ID
     * @param int $id
     * @return array|false
     */
    public function obtenerPorId($id) {
        $sql = "SELECT * FROM Victima WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    /**
     * Buscar víctimas por texto
     * @param string $texto
     * @return array
     */
    public function buscar($texto) {
        $sql = "SELECT * FROM Victima 
                WHERE nombre LIKE :texto 
                OR apellidos LIKE :texto 
                OR documento LIKE :texto 
                OR telefono LIKE :texto 
                OR observaciones LIKE :texto";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':texto' => '%' . $texto . '%']);
        return $stmt->fetchAll();
    }

    /**
     * Validar documento según tipo
     * @param string $tipo Tipo de documento (NIF, NIE, Pasaporte)
     * @param string $documento Número de documento
     * @return bool
     */
    public function validarDocumento($tipo, $documento) {
        if (empty($documento)) {
            return true; // Documento es opcional
        }

        switch ($tipo) {
            case 'NIF':
                return $this->validarNIF($documento);
            case 'NIE':
                return $this->validarNIE($documento);
            case 'Pasaporte':
                return $this->validarPasaporte($documento);
            default:
                return false;
        }
    }

    /**
     * Validar NIF español
     */
    private function validarNIF($nif) {
        $nif = strtoupper(trim($nif));
        if (!preg_match('/^[0-9]{8}[A-Z]$/', $nif)) {
            return false;
        }
        
        $letras = 'TRWAGMYFPDXBNJZSQVHLCKE';
        $numero = substr($nif, 0, 8);
        $letra = substr($nif, 8, 1);
        
        return $letra === $letras[$numero % 23];
    }

    /**
     * Validar NIE español
     */
    private function validarNIE($nie) {
        $nie = strtoupper(trim($nie));
        if (!preg_match('/^[XYZ][0-9]{7}[A-Z]$/', $nie)) {
            return false;
        }
        
        $letras = 'TRWAGMYFPDXBNJZSQVHLCKE';
        $nieNumero = str_replace(['X', 'Y', 'Z'], ['0', '1', '2'], $nie);
        $numero = substr($nieNumero, 0, 8);
        $letra = substr($nie, 8, 1);
        
        return $letra === $letras[$numero % 23];
    }

    /**
     * Validar Pasaporte (formato básico)
     */
    private function validarPasaporte($pasaporte) {
        $pasaporte = strtoupper(trim($pasaporte));
        // Formato básico: 2-3 letras seguidas de 6-9 dígitos
        return preg_match('/^[A-Z]{2,3}[0-9]{6,9}$/', $pasaporte) || 
               strlen($pasaporte) >= 5;
    }
}
