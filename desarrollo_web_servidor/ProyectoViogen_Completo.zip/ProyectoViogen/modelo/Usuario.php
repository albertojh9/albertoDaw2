<?php
/**
 * Clase Usuario - Modelo para gestión de usuarios
 */

require_once MODEL_PATH . 'Database.php';

class Usuario {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Verificar credenciales de usuario
     * @param string $nombre Nombre de usuario
     * @param string $clave Contraseña
     * @return array|false Datos del usuario o false si no existe
     */
    public function verificarCredenciales($nombre, $clave) {
        $sql = "SELECT id, nombre, clave FROM Usuario WHERE nombre = :nombre";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':nombre' => $nombre]);
        $usuario = $stmt->fetch();

        if ($usuario && password_verify($clave, $usuario['clave'])) {
            return [
                'id' => $usuario['id'],
                'nombre' => $usuario['nombre']
            ];
        }

        // Verificación alternativa para clave en texto plano (desarrollo)
        if ($usuario && $usuario['clave'] === $clave) {
            return [
                'id' => $usuario['id'],
                'nombre' => $usuario['nombre']
            ];
        }

        return false;
    }

    /**
     * Obtener usuario por ID
     * @param int $id ID del usuario
     * @return array|false
     */
    public function obtenerPorId($id) {
        $sql = "SELECT id, nombre FROM Usuario WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    /**
     * Crear nuevo usuario
     * @param string $nombre
     * @param string $clave
     * @return int|false ID del usuario creado o false
     */
    public function crear($nombre, $clave) {
        $claveHash = password_hash($clave, PASSWORD_DEFAULT);
        $sql = "INSERT INTO Usuario (nombre, clave) VALUES (:nombre, :clave)";
        $stmt = $this->db->prepare($sql);
        
        try {
            $stmt->execute([
                ':nombre' => $nombre,
                ':clave' => $claveHash
            ]);
            return $this->db->lastInsertId();
        } catch (PDOException $e) {
            return false;
        }
    }
}
