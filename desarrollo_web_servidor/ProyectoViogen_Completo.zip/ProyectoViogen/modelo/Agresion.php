<?php
/**
 * Clase Agresion - Modelo para gestión de agresiones
 */

require_once MODEL_PATH . 'Database.php';

class Agresion {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Registrar nueva agresión
     * @param array $datos Datos de la agresión
     * @return int|false ID de la agresión o false si falla
     */
    public function registrar($datos) {
        $sql = "INSERT INTO Agresion (id_victima, agresor, tipo_agresion, fecha_hora, observaciones) 
                VALUES (:id_victima, :agresor, :tipo_agresion, :fecha_hora, :observaciones)";
        
        $stmt = $this->db->prepare($sql);
        
        try {
            $stmt->execute([
                ':id_victima' => $datos['id_victima'],
                ':agresor' => $datos['agresor'] ?: null,
                ':tipo_agresion' => $datos['tipo_agresion'],
                ':fecha_hora' => $datos['fecha_hora'],
                ':observaciones' => $datos['observaciones'] ?: null
            ]);
            return $this->db->lastInsertId();
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Obtener todas las agresiones
     * @return array
     */
    public function obtenerTodas() {
        $sql = "SELECT a.*, v.nombre as victima_nombre, v.apellidos as victima_apellidos 
                FROM Agresion a 
                JOIN Victima v ON a.id_victima = v.id 
                ORDER BY a.fecha_hora DESC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll();
    }

    /**
     * Obtener agresión por ID
     * @param int $id
     * @return array|false
     */
    public function obtenerPorId($id) {
        $sql = "SELECT a.*, v.nombre as victima_nombre, v.apellidos as victima_apellidos 
                FROM Agresion a 
                JOIN Victima v ON a.id_victima = v.id 
                WHERE a.id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    /**
     * Buscar agresiones por texto en todos los campos
     * @param string $texto
     * @return array
     */
    public function buscar($texto) {
        $sql = "SELECT a.*, v.nombre as victima_nombre, v.apellidos as victima_apellidos,
                       CONCAT(COALESCE(v.nombre, ''), ' ', COALESCE(v.apellidos, '')) as nombre_completo
                FROM Agresion a 
                JOIN Victima v ON a.id_victima = v.id 
                WHERE v.nombre LIKE :texto 
                OR v.apellidos LIKE :texto 
                OR v.telefono LIKE :texto 
                OR v.observaciones LIKE :texto 
                OR a.agresor LIKE :texto 
                OR a.observaciones LIKE :texto
                ORDER BY a.fecha_hora DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':texto' => '%' . $texto . '%']);
        return $stmt->fetchAll();
    }

    /**
     * Obtener agresiones por víctima
     * @param int $idVictima
     * @return array
     */
    public function obtenerPorVictima($idVictima) {
        $sql = "SELECT * FROM Agresion WHERE id_victima = :id_victima ORDER BY fecha_hora DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id_victima' => $idVictima]);
        return $stmt->fetchAll();
    }

    /**
     * Contar agresiones por tipo
     * @return array
     */
    public function contarPorTipo() {
        $sql = "SELECT tipo_agresion, COUNT(*) as total FROM Agresion GROUP BY tipo_agresion";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll();
    }
}
