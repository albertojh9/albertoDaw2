-- Archivo de carga inicial de datos
-- Sistema VioGen

USE viogen;

-- Usuario de prueba (nombre: abcd, clave: 1234)
-- La clave está hasheada con password_hash de PHP
INSERT INTO Usuario (nombre, clave) VALUES 
('abcd', '$2y$10$fRa/F8E0d0cVMeOR8lfNMOnHzbmJ15MJ7Kg7LFcULQndW.gK0sGmS');

-- Víctimas de ejemplo
INSERT INTO Victima (nombre, apellidos, tipo_documento, documento, telefono, observaciones) VALUES
('María', 'García López', 'NIF', '48736215R', '612345678', 'Primera denuncia registrada'),
('Laura', 'Martínez Sánchez', 'NIE', 'X1234567L', '623456789', 'Requiere seguimiento especial'),
('Ana', 'Rodríguez Fernández', 'Pasaporte', 'AB123456', '634567890', NULL),
('Carmen', 'Pérez González', 'NIF', '53218749T', '645678901', 'Caso de alto riesgo'),
('Isabel', 'López Martín', 'NIF', '61928374Y', '656789012', 'Derivada de servicios sociales');

-- Agresiones de ejemplo
INSERT INTO Agresion (id_victima, agresor, tipo_agresion, fecha_hora, observaciones) VALUES
(1, 'Juan García Ruiz - DNI: 12345678A', 'física', '2024-10-15 14:30:00', 'Agresión en domicilio familiar'),
(1, 'Juan García Ruiz - DNI: 12345678A', 'psicológica', '2024-10-20 18:00:00', 'Amenazas verbales'),
(2, 'Pedro López Díaz', 'sexual', '2024-09-25 22:15:00', 'Requiere atención médica urgente'),
(3, NULL, 'psicológica', '2024-11-01 10:00:00', 'Acoso telefónico continuado'),
(4, 'Antonio Sánchez', 'vicaria', '2024-10-30 16:45:00', 'Violencia hacia los hijos'),
(5, 'Manuel Fernández - Sin documento', 'física', '2024-11-05 08:30:00', 'Lesiones leves');
