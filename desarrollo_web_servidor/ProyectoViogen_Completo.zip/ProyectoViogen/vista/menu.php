<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú Principal - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="vista/style.css">
</head>
<body>
    <header>
        <h1><?php echo APP_NAME; ?></h1>
        <div class="user-info">
            Bienvenido, <?php echo htmlspecialchars($usuarioNombre); ?> | 
            <a href="index.php?action=logout">Cerrar Sesión</a>
        </div>
    </header>
    
    <nav>
        <ul>
            <li><a href="index.php?action=menu">Inicio</a></li>
            <li><a href="index.php?action=registrar_victima">Registrar Víctima</a></li>
            <li><a href="index.php?action=registrar_agresion">Registrar Agresión</a></li>
        </ul>
    </nav>
    
    <div class="container">
        <?php if (isset($mensaje)): ?>
            <div class="mensaje mensaje-exito"><?php echo htmlspecialchars($mensaje); ?></div>
        <?php endif; ?>
        
        <!-- Buscador de Agresiones -->
        <div class="form-container">
            <h2>Informe de Agresiones</h2>
            <p>Busque agresiones por cualquier campo: nombre, apellidos, teléfono, observaciones...</p>
            
            <form action="index.php" method="GET" class="search-box">
                <input type="hidden" name="action" value="menu">
                <input type="text" name="q" placeholder="Introduzca texto de búsqueda..." 
                       value="<?php echo htmlspecialchars($datosBusqueda['busqueda']); ?>">
                <button type="submit" class="btn btn-primary">Buscar</button>
            </form>
            
            <?php if (!empty($datosBusqueda['busqueda'])): ?>
                <?php if (!empty($datosBusqueda['resultados'])): ?>
                    <h3>Resultados de búsqueda para: "<?php echo htmlspecialchars($datosBusqueda['busqueda']); ?>"</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Nombre Completo Víctima</th>
                                <th>Tipo de Agresión</th>
                                <th>Fecha de Agresión</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($datosBusqueda['resultados'] as $agresion): ?>
                                <tr>
                                    <td>
                                        <?php 
                                        $nombreCompleto = trim(
                                            ($agresion['victima_nombre'] ?? '') . ' ' . 
                                            ($agresion['victima_apellidos'] ?? '')
                                        );
                                        echo htmlspecialchars($nombreCompleto ?: 'Sin nombre');
                                        ?>
                                    </td>
                                    <td><?php echo htmlspecialchars(ucfirst($agresion['tipo_agresion'])); ?></td>
                                    <td>
                                        <?php 
                                        $fecha = new DateTime($agresion['fecha_hora']);
                                        echo $fecha->format('d/m/Y H:i');
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <p><small>Total de resultados: <?php echo count($datosBusqueda['resultados']); ?></small></p>
                <?php else: ?>
                    <div class="mensaje mensaje-info">
                        No se encontraron resultados para "<?php echo htmlspecialchars($datosBusqueda['busqueda']); ?>"
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        
        <!-- Acciones rápidas -->
        <div class="form-container">
            <h2>Acciones Rápidas</h2>
            <p>
                <a href="index.php?action=registrar_victima" class="btn btn-success">Registrar Nueva Víctima</a>
                <a href="index.php?action=registrar_agresion" class="btn btn-primary">Registrar Nueva Agresión</a>
            </p>
        </div>
    </div>
</body>
</html>
