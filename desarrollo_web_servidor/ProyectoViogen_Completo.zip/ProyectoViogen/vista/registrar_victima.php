<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Víctima - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="vista/style.css">
</head>
<body>
    <header>
        <h1><?php echo APP_NAME; ?></h1>
        <div class="user-info">
            Bienvenido, <?php echo htmlspecialchars($_SESSION['usuario_nombre']); ?> | 
            <a href="index.php?action=logout">Cerrar Sesión</a>
        </div>
    </header>
    
    <nav>
        <ul>
            <li><a href="index.php?action=menu">Inicio</a></li>
            <li><a href="index.php?action=registrar_victima">Registrar Víctima</a></li>
            <li><a href="index.php?action=registrar_agresion">Registrar Agresión</a></li>
        </ul>
    </nav>
    
    <div class="container">
        <div class="form-container">
            <h2>Registro de Víctima</h2>
            
            <?php if (isset($error)): ?>
                <div class="mensaje mensaje-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <p><small>Todos los campos son opcionales, pero debe proporcionar al menos un nombre o una observación.</small></p>
            
            <form action="index.php?action=procesar_victima" method="POST">
                <div class="form-group">
                    <label for="nombre">Nombre:</label>
                    <input type="text" id="nombre" name="nombre" 
                           value="<?php echo htmlspecialchars($datos['nombre'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="apellidos">Apellidos:</label>
                    <input type="text" id="apellidos" name="apellidos"
                           value="<?php echo htmlspecialchars($datos['apellidos'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="tipo_documento">Tipo de Documento:</label>
                    <select id="tipo_documento" name="tipo_documento">
                        <option value="">-- Seleccione --</option>
                        <?php foreach ($tiposDocumento as $tipo): ?>
                            <option value="<?php echo $tipo; ?>" 
                                <?php echo (isset($datos['tipo_documento']) && $datos['tipo_documento'] === $tipo) ? 'selected' : ''; ?>>
                                <?php echo $tipo; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <small>El documento será validado según el tipo seleccionado.</small>
                </div>
                
                <div class="form-group">
                    <label for="documento">Número de Documento:</label>
                    <input type="text" id="documento" name="documento"
                           value="<?php echo htmlspecialchars($datos['documento'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="telefono">Teléfono:</label>
                    <input type="tel" id="telefono" name="telefono"
                           value="<?php echo htmlspecialchars($datos['telefono'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="observaciones">Observaciones:</label>
                    <textarea id="observaciones" name="observaciones"><?php echo htmlspecialchars($datos['observaciones'] ?? ''); ?></textarea>
                </div>
                
                <button type="submit" class="btn btn-success">Registrar Víctima</button>
                <a href="index.php?action=menu" class="btn btn-secondary">Cancelar</a>
            </form>
        </div>
    </div>
</body>
</html>
