<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>401 - Acceso No Autorizado</title>
    <link rel="stylesheet" href="vista/style.css">
</head>
<body>
    <div class="container">
        <div class="error-container">
            <h1>401</h1>
            <p><?php echo MSG_UNAUTHORIZED; ?></p>
            <p>Debe iniciar sesión para acceder a esta página.</p>
            <a href="index.php?action=login" class="btn btn-primary">Ir al Login</a>
        </div>
    </div>
</body>
</html>
