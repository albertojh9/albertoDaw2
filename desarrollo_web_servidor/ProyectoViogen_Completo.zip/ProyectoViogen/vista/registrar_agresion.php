<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Agresión - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="vista/style.css">
</head>
<body>
    <header>
        <h1><?php echo APP_NAME; ?></h1>
        <div class="user-info">
            Bienvenido, <?php echo htmlspecialchars($_SESSION['usuario_nombre']); ?> | 
            <a href="index.php?action=logout">Cerrar Sesión</a>
        </div>
    </header>
    
    <nav>
        <ul>
            <li><a href="index.php?action=menu">Inicio</a></li>
            <li><a href="index.php?action=registrar_victima">Registrar Víctima</a></li>
            <li><a href="index.php?action=registrar_agresion">Registrar Agresión</a></li>
        </ul>
    </nav>
    
    <div class="container">
        <div class="form-container">
            <h2>Registro de Agresión</h2>
            
            <?php if (isset($error)): ?>
                <div class="mensaje mensaje-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if (empty($victimas)): ?>
                <div class="mensaje mensaje-info">
                    No hay víctimas registradas. 
                    <a href="index.php?action=registrar_victima">Registre una víctima primero</a>.
                </div>
            <?php else: ?>
                <form action="index.php?action=procesar_agresion" method="POST">
                    <div class="form-group">
                        <label for="id_victima">Víctima: *</label>
                        <select id="id_victima" name="id_victima" required>
                            <option value="">-- Seleccione víctima --</option>
                            <?php foreach ($victimas as $victima): ?>
                                <option value="<?php echo $victima['id']; ?>"
                                    <?php echo (isset($datos['id_victima']) && $datos['id_victima'] == $victima['id']) ? 'selected' : ''; ?>>
                                    <?php 
                                    $nombreCompleto = trim(($victima['nombre'] ?? '') . ' ' . ($victima['apellidos'] ?? ''));
                                    echo htmlspecialchars($nombreCompleto ?: 'ID: ' . $victima['id']);
                                    if ($victima['documento']) {
                                        echo ' (' . htmlspecialchars($victima['documento']) . ')';
                                    }
                                    ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="agresor">Agresor:</label>
                        <textarea id="agresor" name="agresor" 
                                  placeholder="Descripción o datos identificativos del agresor"><?php echo htmlspecialchars($datos['agresor'] ?? ''); ?></textarea>
                        <small>Texto con la descripción o datos identificativos del agresor. No obligatorio.</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="tipo_agresion">Tipo de Agresión: *</label>
                        <select id="tipo_agresion" name="tipo_agresion" required>
                            <option value="">-- Seleccione tipo --</option>
                            <?php foreach ($tiposAgresion as $tipo): ?>
                                <option value="<?php echo $tipo; ?>"
                                    <?php echo (isset($datos['tipo_agresion']) && $datos['tipo_agresion'] === $tipo) ? 'selected' : ''; ?>>
                                    <?php echo ucfirst($tipo); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="fecha_hora">Fecha y Hora: *</label>
                        <input type="datetime-local" id="fecha_hora" name="fecha_hora" required
                               value="<?php echo htmlspecialchars($datos['fecha_hora'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="observaciones">Observaciones:</label>
                        <textarea id="observaciones" name="observaciones"><?php echo htmlspecialchars($datos['observaciones'] ?? ''); ?></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-success">Registrar Agresión</button>
                    <a href="index.php?action=menu" class="btn btn-secondary">Cancelar</a>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
