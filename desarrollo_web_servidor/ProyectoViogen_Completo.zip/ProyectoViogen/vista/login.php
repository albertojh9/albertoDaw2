<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="vista/style.css">
</head>
<body>
    <div class="login-container">
        <div class="form-container">
            <h2><?php echo APP_NAME; ?></h2>
            
            <?php if (isset($mensaje)): ?>
                <div class="mensaje mensaje-exito"><?php echo htmlspecialchars($mensaje); ?></div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="mensaje mensaje-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <form action="index.php?action=procesar_login" method="POST">
                <div class="form-group">
                    <label for="nombre">Usuario:</label>
                    <input type="text" id="nombre" name="nombre" required minlength="4" 
                           placeholder="Mínimo 4 caracteres">
                </div>
                
                <div class="form-group">
                    <label for="clave">Contraseña:</label>
                    <input type="password" id="clave" name="clave" required minlength="4"
                           placeholder="Mínimo 4 caracteres">
                </div>
                
                <button type="submit" class="btn btn-primary" style="width: 100%;">
                    Iniciar Sesión
                </button>
            </form>
        </div>
    </div>
</body>
</html>
