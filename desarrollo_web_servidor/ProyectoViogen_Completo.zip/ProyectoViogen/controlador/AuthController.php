<?php
/**
 * Controlador de Autenticación
 * Gestiona login y logout de usuarios
 */

require_once MODEL_PATH . 'Usuario.php';

class AuthController {
    private $usuarioModel;

    public function __construct() {
        $this->usuarioModel = new Usuario();
    }

    /**
     * Mostrar formulario de login
     */
    public function mostrarLogin() {
        $error = $_SESSION['error'] ?? null;
        $mensaje = $_SESSION['mensaje'] ?? null;
        unset($_SESSION['error'], $_SESSION['mensaje']);
        
        include VIEW_PATH . 'login.php';
    }

    /**
     * Procesar login
     */
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: index.php?action=login');
            exit;
        }

        // Sanitizar entrada
        $nombre = $this->sanitizar($_POST['nombre'] ?? '');
        $clave = $_POST['clave'] ?? '';

        // Validar campos
        if (strlen($nombre) < MIN_LENGTH_USER || strlen($clave) < MIN_LENGTH_PASS) {
            $_SESSION['error'] = 'El usuario y la contraseña deben tener al menos 4 caracteres';
            header('Location: index.php?action=login');
            exit;
        }

        // Verificar credenciales
        $usuario = $this->usuarioModel->verificarCredenciales($nombre, $clave);

        if ($usuario) {
            // Regenerar ID de sesión por seguridad
            session_regenerate_id(true);
            
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['usuario_nombre'] = $usuario['nombre'];
            $_SESSION['mensaje'] = MSG_LOGIN_SUCCESS;
            
            header('Location: index.php?action=menu');
            exit;
        } else {
            $_SESSION['error'] = MSG_LOGIN_ERROR;
            header('Location: index.php?action=login');
            exit;
        }
    }

    /**
     * Cerrar sesión
     */
    public function logout() {
        // Destruir todas las variables de sesión
        $_SESSION = [];
        
        // Destruir la cookie de sesión
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        
        // Destruir la sesión
        session_destroy();
        
        // Reiniciar sesión para mostrar mensaje
        session_start();
        $_SESSION['mensaje'] = MSG_LOGOUT_SUCCESS;
        
        header('Location: index.php?action=login');
        exit;
    }

    /**
     * Sanitizar entrada
     */
    private function sanitizar($valor) {
        return htmlspecialchars(trim($valor), ENT_QUOTES, 'UTF-8');
    }
}
