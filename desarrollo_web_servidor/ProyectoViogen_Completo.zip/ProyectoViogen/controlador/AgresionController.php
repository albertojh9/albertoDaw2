<?php
/**
 * Controlador de Agresiones
 * Gestiona el registro y búsqueda de agresiones
 */

require_once MODEL_PATH . 'Agresion.php';
require_once MODEL_PATH . 'Victima.php';

class AgresionController {
    private $agresionModel;
    private $victimaModel;

    public function __construct() {
        $this->agresionModel = new Agresion();
        $this->victimaModel = new Victima();
    }

    /**
     * Mostrar formulario de registro de agresión
     */
    public function mostrarFormulario() {
        $error = $_SESSION['error'] ?? null;
        $datos = $_SESSION['datos_agresion'] ?? [];
        unset($_SESSION['error'], $_SESSION['datos_agresion']);
        
        $victimas = $this->victimaModel->obtenerTodas();
        $tiposAgresion = TIPOS_AGRESION;
        
        include VIEW_PATH . 'registrar_agresion.php';
    }

    /**
     * Procesar registro de agresión
     */
    public function registrar() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: index.php?action=registrar_agresion');
            exit;
        }

        // Sanitizar todos los campos
        $datos = [
            'id_victima' => filter_var($_POST['id_victima'] ?? '', FILTER_VALIDATE_INT),
            'agresor' => $this->sanitizar($_POST['agresor'] ?? ''),
            'tipo_agresion' => $this->sanitizar($_POST['tipo_agresion'] ?? ''),
            'fecha_hora' => $this->sanitizar($_POST['fecha_hora'] ?? ''),
            'observaciones' => $this->sanitizar($_POST['observaciones'] ?? '')
        ];

        // Validar campos obligatorios
        $errores = [];
        
        if (!$datos['id_victima']) {
            $errores[] = 'Debe seleccionar una víctima';
        }
        
        if (empty($datos['tipo_agresion']) || !in_array($datos['tipo_agresion'], TIPOS_AGRESION)) {
            $errores[] = 'Debe seleccionar un tipo de agresión válido';
        }
        
        if (empty($datos['fecha_hora'])) {
            $errores[] = 'Debe proporcionar la fecha y hora de la agresión';
        } else {
            // Validar formato de fecha
            $fecha = DateTime::createFromFormat('Y-m-d\TH:i', $datos['fecha_hora']);
            if (!$fecha) {
                $errores[] = 'El formato de fecha no es válido';
            } else {
                $datos['fecha_hora'] = $fecha->format('Y-m-d H:i:s');
            }
        }

        if (!empty($errores)) {
            $_SESSION['error'] = implode('<br>', $errores);
            $_SESSION['datos_agresion'] = $datos;
            header('Location: index.php?action=registrar_agresion');
            exit;
        }

        // Registrar agresión
        $id = $this->agresionModel->registrar($datos);

        if ($id) {
            $_SESSION['mensaje'] = MSG_AGRESION_REGISTRADA;
            header('Location: index.php?action=menu');
            exit;
        } else {
            $_SESSION['error'] = 'Error al registrar la agresión';
            $_SESSION['datos_agresion'] = $datos;
            header('Location: index.php?action=registrar_agresion');
            exit;
        }
    }

    /**
     * Buscar agresiones
     */
    public function buscar() {
        $busqueda = $this->sanitizar($_GET['q'] ?? $_POST['q'] ?? '');
        $resultados = [];
        
        if (!empty($busqueda)) {
            $resultados = $this->agresionModel->buscar($busqueda);
        }
        
        return [
            'busqueda' => $busqueda,
            'resultados' => $resultados
        ];
    }

    /**
     * Sanitizar entrada
     */
    private function sanitizar($valor) {
        return htmlspecialchars(trim($valor), ENT_QUOTES, 'UTF-8');
    }
}
