<?php
/**
 * Controlador del Menú Principal
 * Gestiona la vista principal y el buscador de agresiones
 */

require_once CONTROLLER_PATH . 'AgresionController.php';

class MenuController {
    private $agresionController;

    public function __construct() {
        $this->agresionController = new AgresionController();
    }

    /**
     * Mostrar menú principal con buscador
     */
    public function mostrar() {
        $mensaje = $_SESSION['mensaje'] ?? null;
        unset($_SESSION['mensaje']);
        
        // Procesar búsqueda si existe
        $datosBusqueda = $this->agresionController->buscar();
        
        $usuarioNombre = $_SESSION['usuario_nombre'] ?? 'Usuario';
        
        include VIEW_PATH . 'menu.php';
    }
}
