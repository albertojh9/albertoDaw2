<?php
/**
 * Controlador de Víctimas
 * Gestiona el registro y consulta de víctimas
 */

require_once MODEL_PATH . 'Victima.php';

class VictimaController {
    private $victimaModel;

    public function __construct() {
        $this->victimaModel = new Victima();
    }

    /**
     * Mostrar formulario de registro de víctima
     */
    public function mostrarFormulario() {
        $error = $_SESSION['error'] ?? null;
        $datos = $_SESSION['datos_victima'] ?? [];
        unset($_SESSION['error'], $_SESSION['datos_victima']);
        
        $tiposDocumento = TIPOS_DOCUMENTO;
        
        include VIEW_PATH . 'registrar_victima.php';
    }

    /**
     * Procesar registro de víctima
     */
    public function registrar() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: index.php?action=registrar_victima');
            exit;
        }

        // Sanitizar todos los campos
        $datos = [
            'nombre' => $this->sanitizar($_POST['nombre'] ?? ''),
            'apellidos' => $this->sanitizar($_POST['apellidos'] ?? ''),
            'tipo_documento' => $this->sanitizar($_POST['tipo_documento'] ?? ''),
            'documento' => $this->sanitizar($_POST['documento'] ?? ''),
            'telefono' => $this->sanitizar($_POST['telefono'] ?? ''),
            'observaciones' => $this->sanitizar($_POST['observaciones'] ?? '')
        ];

        // Validar que al menos haya nombre u observaciones
        if (empty($datos['nombre']) && empty($datos['observaciones'])) {
            $_SESSION['error'] = 'Debe proporcionar al menos un nombre o una observación';
            $_SESSION['datos_victima'] = $datos;
            header('Location: index.php?action=registrar_victima');
            exit;
        }

        // Validar documento si se proporciona
        if (!empty($datos['documento']) && !empty($datos['tipo_documento'])) {
            if (!$this->victimaModel->validarDocumento($datos['tipo_documento'], $datos['documento'])) {
                $_SESSION['error'] = 'El documento no es válido para el tipo seleccionado';
                $_SESSION['datos_victima'] = $datos;
                header('Location: index.php?action=registrar_victima');
                exit;
            }
        }

        // Registrar víctima
        $id = $this->victimaModel->registrar($datos);

        if ($id) {
            $_SESSION['mensaje'] = MSG_VICTIMA_REGISTRADA;
            header('Location: index.php?action=menu');
            exit;
        } else {
            $_SESSION['error'] = 'Error al registrar la víctima';
            $_SESSION['datos_victima'] = $datos;
            header('Location: index.php?action=registrar_victima');
            exit;
        }
    }

    /**
     * Obtener lista de víctimas para select
     */
    public function obtenerListaVictimas() {
        return $this->victimaModel->obtenerTodas();
    }

    /**
     * Sanitizar entrada
     */
    private function sanitizar($valor) {
        return htmlspecialchars(trim($valor), ENT_QUOTES, 'UTF-8');
    }
}
