# Proyecto VioGen - Sistema de Gestión de Violencia de Género

## Descripción
Sistema de gestión de agresiones de violencia de género desarrollado con PHP siguiendo el patrón MVC.

## Credenciales de Acceso
- **Usuario:** abcd
- **Contraseña:** 1234

## Estructura del Proyecto

```
ProyectoViogen/
├── index.php                    # Punto de entrada único (Front Controller)
├── config/
│   └── config.php               # Constantes de configuración
├── controlador/
│   ├── AuthController.php       # Controlador de autenticación
│   ├── VictimaController.php    # Controlador de víctimas
│   ├── AgresionController.php   # Controlador de agresiones
│   └── MenuController.php       # Controlador del menú principal
├── modelo/
│   ├── Database.php             # Conexión a base de datos (Singleton)
│   ├── Usuario.php              # Modelo de usuarios
│   ├── Victima.php              # Modelo de víctimas
│   └── Agresion.php             # Modelo de agresiones
├── vista/
│   ├── style.css                # Estilos CSS
│   ├── login.php                # Vista de login
│   ├── 401.php                  # Vista de error 401
│   ├── menu.php                 # Vista del menú principal con buscador
│   ├── registrar_victima.php    # Vista de registro de víctima
│   └── registrar_agresion.php   # Vista de registro de agresión
└── sql/
    ├── viogen.sql               # Creación de base de datos y tablas
    └── datos_viogen.sql         # Carga inicial de datos
```

## Implementaciones Realizadas

### 1. Arquitectura MVC Completa
Se ha implementado completamente el patrón MVC:
- **Modelos** en `/modelo/`: Database.php, Usuario.php, Victima.php, Agresion.php
- **Vistas** en `/vista/`: login.php, menu.php, registrar_victima.php, registrar_agresion.php, 401.php
- **Controladores** en `/controlador/`: AuthController.php, VictimaController.php, AgresionController.php, MenuController.php

### 2. Sistema de Autenticación (Login/Logout)
**Archivos:** `controlador/AuthController.php`, `vista/login.php`

- Login con validación de usuario (mínimo 4 caracteres)
- Contraseña (mínimo 4 caracteres)
- Sesión de usuario con ID (no se guarda la clave)
- Logout que destruye la sesión completamente
- Regeneración de ID de sesión por seguridad

### 3. Middleware de Autenticación
**Archivo:** `index.php`

- Punto de entrada único que verifica autenticación
- Genera error HTTP 401 si no hay sesión válida
- Todas las vistas protegidas requieren login previo

### 4. Registro de Víctima
**Archivos:** `controlador/VictimaController.php`, `modelo/Victima.php`, `vista/registrar_victima.php`

Campos implementados:
- Nombre (opcional)
- Apellidos (opcional)
- Tipo de documento: NIF, NIE, Pasaporte (con validación)
- Documento (opcional, validado según tipo)
- Teléfono (opcional)
- Observaciones (opcional)

Regla: Al menos debe haber nombre u observaciones.

### 5. Registro de Agresión
**Archivos:** `controlador/AgresionController.php`, `modelo/Agresion.php`, `vista/registrar_agresion.php`

Campos implementados:
- Víctima (obligatorio, selector)
- Agresor (texto descriptivo, no obligatorio)
- Tipo de agresión: física, psicológica, sexual, vicaria (obligatorio)
- Fecha y hora (obligatorio)
- Observaciones (opcional)

### 6. Informe de Agresiones (Buscador)
**Archivos:** `controlador/MenuController.php`, `modelo/Agresion.php`, `vista/menu.php`

- Buscador en el menú principal
- Búsqueda en todos los campos textuales (nombre, apellidos, teléfono, observaciones)
- Resultados en tabla con:
  - Nombre completo de la víctima
  - Tipo de agresión
  - Fecha de agresión
- Ordenados por fecha descendente

### 7. Base de Datos
**Archivos:** `sql/viogen.sql`, `sql/datos_viogen.sql`

- Base de datos: viogen
- Usuario: uviogen
- Contraseña: cviogen
- Tablas: Usuario, Victima, Agresion (según estructura proporcionada)
- Datos iniciales incluidos

### 8. Configuración Centralizada
**Archivo:** `config/config.php`

Contiene todas las constantes:
- Configuración de BD (host, nombre, usuario, contraseña)
- Rutas de la aplicación
- Tipos de documento y agresión válidos
- Mensajes del sistema
- Configuración de sesión

### 9. Seguridad Implementada

#### Sanitización
Todos los campos de formularios son sanitizados antes de almacenarse:
- `htmlspecialchars()` con ENT_QUOTES y UTF-8
- `trim()` para eliminar espacios

#### Validación de Documentos
- **NIF**: Formato 8 dígitos + letra, con validación de letra correcta
- **NIE**: Formato X/Y/Z + 7 dígitos + letra, con validación
- **Pasaporte**: Formato básico validado

#### Prepared Statements
Todas las consultas SQL usan PDO con prepared statements para prevenir SQL injection.

#### Protección de Sesión
- Regeneración de ID de sesión en login
- Destrucción completa en logout

### 10. URLs Relativas
Todas las URLs son relativas, no se usan URLs absolutas:
- `index.php?action=login`
- `index.php?action=menu`
- `index.php?action=registrar_victima`
- etc.

### 11. Mensajes de Confirmación/Error
Tras cada operación:
- Éxito: Redirige al menú con mensaje de confirmación
- Error: Permanece en la vista con mensaje informativo

## Instalación

1. Importar la base de datos:
```bash
mysql -u root -p < sql/viogen.sql
mysql -u root -p viogen < sql/datos_viogen.sql
```

2. Configurar el servidor web para apuntar a la carpeta del proyecto.

3. Acceder a `index.php` en el navegador.

## Requisitos
- PHP 7.4 o superior
- MySQL 5.7 o superior
- Extensión PDO de PHP

## Funcionalidades Cumplidas según Rúbrica

### Funcionalidad (Punto 1)
- ✅ Login implementado
- ✅ Logout implementado
- ✅ Registro de Víctima implementado
- ✅ Registro de Agresión implementado
- ✅ Informe de Agresiones (buscador) implementado

### Corrección (Punto 2)
- ✅ Punto de entrada único (index.php)
- ✅ Middleware de autenticación con error 401
- ✅ Campos opcionales/obligatorios según especificación
- ✅ Validaciones correctas

### Completitud (Punto 3)
- ✅ Validación de documentos (NIF, NIE, Pasaporte)
- ✅ Tipos de agresión: física, psicológica, sexual, vicaria
- ✅ Campos opcionales correctamente implementados
- ✅ Búsqueda en todos los campos textuales
- ✅ Resultados ordenados por fecha descendente

### Calidad de Código I (Punto 4)
- ✅ Archivo config.php con todas las constantes

### Calidad de Código II (Punto 5)
- ✅ Patrón MVC correctamente implementado
- ✅ Estructura de directorios: controlador/, modelo/, vista/
- ✅ Controladores gestionan la lógica
- ✅ Modelos acceden a la base de datos
- ✅ Vistas solo muestran información

### Seguridad (Punto 6)
- ✅ Sanitización de todos los campos con htmlspecialchars()
- ✅ Validación de tipos de documento
- ✅ Prepared statements en todas las consultas
- ✅ Protección contra SQL injection

### Presentación (Punto 7)
- ✅ Interfaz limpia y profesional
- ✅ CSS completo y responsive
- ✅ Mensajes informativos claros
- ✅ Navegación intuitiva

## Autor
Alberto - DAW 2º - IES Castelar

## Versión
1.0.0
